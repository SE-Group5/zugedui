/*
Navicat MySQL Data Transfer

Source Server         : blog
Source Server Version : 50557
Source Host           : 47.107.88.132:3306
Source Database       : kuaidi

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2020-12-15 00:21:18
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for team_ge
-- ----------------------------
DROP TABLE IF EXISTS `team_ge`;
CREATE TABLE `team_ge` (
  `college_id` int(11) NOT NULL,
  `college_name` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `college_logo` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`college_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of team_ge
-- ----------------------------
INSERT INTO `team_ge` VALUES ('1', '电子与信息学院', '/image/college_logo/cl.png');
INSERT INTO `team_ge` VALUES ('2', '机电学院', '/image/college_logo/hh.png');
INSERT INTO `team_ge` VALUES ('3', '汽车与交通工程学院', '/image/college_logo/hz.png');
INSERT INTO `team_ge` VALUES ('4', '计算机科学学院', '/image/college_logo/xg.png');
INSERT INTO `team_ge` VALUES ('5', '外国语学院', '/image/college_logo/wy.png');
INSERT INTO `team_ge` VALUES ('6', '自动化学院', '/image/college_logo/fxq.png');
INSERT INTO `team_ge` VALUES ('7', '数学与系统科学学院', '/image/college_logo/sx.png');
INSERT INTO `team_ge` VALUES ('8', '光电工程学院', '/image/college_logo/cg.png');
INSERT INTO `team_ge` VALUES ('9', '教育科学与技术学院', '/image/college_logo/jg.png');
INSERT INTO `team_ge` VALUES ('10', '管理学院', '/image/college_logo/ty.png');
INSERT INTO `team_ge` VALUES ('11', '财经学院', '/image/college_logo/tm.png');
INSERT INTO `team_ge` VALUES ('12', '文学与传媒学院', '/image/college_logo/ys.png');
INSERT INTO `team_ge` VALUES ('14', '法学与知识产权学院', '/image/college_logo/wf.png');
INSERT INTO `team_ge` VALUES ('15', '音乐学院', '/image/college_logo/yy.png');
INSERT INTO `team_ge` VALUES ('16', '美术学院', '/image/college_logo/th.png');
INSERT INTO `team_ge` VALUES ('20', '网络空间安全学院', '/image/college_logo/rj.png');
INSERT INTO `team_ge` VALUES ('22', '国际教育学院', '/image/college_logo/gj.png');
