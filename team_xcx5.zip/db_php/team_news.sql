/*
Navicat MySQL Data Transfer

Source Server         : blog
Source Server Version : 50557
Source Host           : 47.107.88.132:3306
Source Database       : kuaidi

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2020-12-15 00:21:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for team_news
-- ----------------------------
DROP TABLE IF EXISTS `team_news`;
CREATE TABLE `team_news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `post_time` date NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `com_id` int(11) NOT NULL,
  `num_people` int(11) DEFAULT '1',
  `stage` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `detail` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `aim_college` int(11) DEFAULT NULL,
  `news_remain_time` int(11) DEFAULT '10',
  `views` int(11) DEFAULT '0',
  `likes` int(11) DEFAULT '0',
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`news_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of team_news
-- ----------------------------
INSERT INTO `team_news` VALUES ('46', 'aaaaa爱全宗', '2020-12-14', '1', '0', '1', 'qwe', 'zzzzz', '0', '10', '0', '1', null);
