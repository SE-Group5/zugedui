/*
Navicat MySQL Data Transfer

Source Server         : blog
Source Server Version : 50557
Source Host           : 47.107.88.132:3306
Source Database       : kuaidi

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2020-12-15 00:21:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for team_statistics
-- ----------------------------
DROP TABLE IF EXISTS `team_statistics`;
CREATE TABLE `team_statistics` (
  `total_name` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `total` int(11) DEFAULT '0',
  PRIMARY KEY (`total_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of team_statistics
-- ----------------------------
