/*
Navicat MySQL Data Transfer

Source Server         : blog
Source Server Version : 50557
Source Host           : 47.107.88.132:3306
Source Database       : kuaidi

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2020-12-15 00:21:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for team_college
-- ----------------------------
DROP TABLE IF EXISTS `team_college`;
CREATE TABLE `team_college` (
  `com_id` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  PRIMARY KEY (`com_id`,`college_id`) USING BTREE,
  KEY `foreign_key2` (`college_id`) USING BTREE,
  CONSTRAINT `team_college_ibfk_1` FOREIGN KEY (`com_id`) REFERENCES `team_competition` (`com_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `team_college_ibfk_2` FOREIGN KEY (`college_id`) REFERENCES `team_ge` (`college_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of team_college
-- ----------------------------
INSERT INTO `team_college` VALUES ('1', '1');
INSERT INTO `team_college` VALUES ('2', '1');
INSERT INTO `team_college` VALUES ('10', '1');
INSERT INTO `team_college` VALUES ('1', '2');
INSERT INTO `team_college` VALUES ('2', '2');
INSERT INTO `team_college` VALUES ('5', '2');
INSERT INTO `team_college` VALUES ('10', '2');
INSERT INTO `team_college` VALUES ('1', '3');
INSERT INTO `team_college` VALUES ('2', '3');
INSERT INTO `team_college` VALUES ('8', '3');
INSERT INTO `team_college` VALUES ('10', '3');
INSERT INTO `team_college` VALUES ('1', '4');
INSERT INTO `team_college` VALUES ('2', '4');
INSERT INTO `team_college` VALUES ('10', '4');
INSERT INTO `team_college` VALUES ('11', '4');
INSERT INTO `team_college` VALUES ('1', '5');
INSERT INTO `team_college` VALUES ('2', '5');
INSERT INTO `team_college` VALUES ('10', '5');
INSERT INTO `team_college` VALUES ('1', '6');
INSERT INTO `team_college` VALUES ('2', '6');
INSERT INTO `team_college` VALUES ('10', '6');
INSERT INTO `team_college` VALUES ('1', '7');
INSERT INTO `team_college` VALUES ('2', '7');
INSERT INTO `team_college` VALUES ('10', '7');
INSERT INTO `team_college` VALUES ('1', '8');
INSERT INTO `team_college` VALUES ('2', '8');
INSERT INTO `team_college` VALUES ('10', '8');
INSERT INTO `team_college` VALUES ('1', '9');
INSERT INTO `team_college` VALUES ('2', '9');
INSERT INTO `team_college` VALUES ('6', '9');
INSERT INTO `team_college` VALUES ('10', '9');
INSERT INTO `team_college` VALUES ('1', '10');
INSERT INTO `team_college` VALUES ('2', '10');
INSERT INTO `team_college` VALUES ('10', '10');
INSERT INTO `team_college` VALUES ('1', '11');
INSERT INTO `team_college` VALUES ('2', '11');
INSERT INTO `team_college` VALUES ('7', '11');
INSERT INTO `team_college` VALUES ('10', '11');
INSERT INTO `team_college` VALUES ('1', '12');
INSERT INTO `team_college` VALUES ('2', '12');
INSERT INTO `team_college` VALUES ('4', '12');
INSERT INTO `team_college` VALUES ('10', '12');
INSERT INTO `team_college` VALUES ('1', '14');
INSERT INTO `team_college` VALUES ('2', '14');
INSERT INTO `team_college` VALUES ('10', '14');
INSERT INTO `team_college` VALUES ('1', '15');
INSERT INTO `team_college` VALUES ('2', '15');
INSERT INTO `team_college` VALUES ('9', '15');
INSERT INTO `team_college` VALUES ('10', '15');
INSERT INTO `team_college` VALUES ('1', '16');
INSERT INTO `team_college` VALUES ('2', '16');
INSERT INTO `team_college` VALUES ('10', '16');
INSERT INTO `team_college` VALUES ('1', '20');
INSERT INTO `team_college` VALUES ('2', '20');
INSERT INTO `team_college` VALUES ('3', '20');
INSERT INTO `team_college` VALUES ('10', '20');
INSERT INTO `team_college` VALUES ('11', '20');
INSERT INTO `team_college` VALUES ('1', '22');
INSERT INTO `team_college` VALUES ('2', '22');
INSERT INTO `team_college` VALUES ('10', '22');
