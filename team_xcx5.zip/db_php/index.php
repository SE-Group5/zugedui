<?php

    // 组队---更新用户信息
    public function team_update_user_info(Request $request){
        $is_sign_up = $request->is_sign_up;  //注册信息还是更新信息,true表示注册
        $college = $request->college;      //用户所属学院
        $user_name = $request->userName;  //用户姓名
        $avatar = $request->avatar;  //头像
        $sex = $request->sex;    //性别
        $grade = $request->grade;   //年级
        $experience = $request->experience;  //经历
        $qq = $request->qq;   //QQ
        $weixin = $request->weixin;   //微信
        $tel = $request->tel;  //电话
        $introduction = $request->introduction;  //简介
        
        $college_id=DB::table('team_ge')->where('college_name',$college)->value('college_id');
        
        if($college_id){
            $is_login=DB::table('team_user')->where('user_name',$user_name)->where('college_id',$college_id)->first();
            if(!$is_login){  //注册信息
                $res=DB::insert("insert into 
                team_user( user_name, avatar, sex, college_id, grade, experience, qq, weixin, tel, user_introduction) 
                values
                ('$user_name', '$avatar', '$sex', $college_id, '$grade', '$experience', 
                '$qq', '$weixin', '$tel', '$introduction');");
                
        
                if($res){
                    $user=DB::table('team_user')->where('user_name',$user_name)->first();
                    $college=Db::table('team_ge')->where('college_id',$college_id)->first();
                    Cache::put(md5($user_name.time()),$user);
                    return json_encode(['status'=>200, 'msg'=>'注册成功','token'=>md5($user_name.time()),'college'=>$college]);
                }
                
                return json_encode(['status'=>500, 'msg'=>'注册失败']);
        
            }else{  //更新信息
                $id=$is_login->id;
                $res=DB::update("update team_user set user_name = ?, avatar = ?, sex = ?, college_id = ?,grade = ?, experience =?,qq =?,weixin =?,tel =?, user_introduction =? where id =".$id,array($user_name,$avatar,$sex,$college_id,$grade,$experience,$qq,$weixin,$tel,$introduction));
                
                if($res==0){
                    $user=DB::table('team_user')->where('id',$is_login->id)->first();
                    $college=Db::table('team_ge')->where('college_id',$college_id)->first();
                    Cache::put(md5($user_name.time()),$user);
                    return json_encode(['status'=>200, 'msg'=>'更新成功','token'=>md5($user_name.time()),'college'=>$college]);
                }
                return json_encode(['status'=>500, 'msg'=>'更新失败']);
                
            }            
        }
        
    }
    
    // 组队---登录
    public function team_login(Request $request){
        if(Cache::has($request->token)){
            $user=Cache::get($request->token);
            $college=Db::table('team_ge')->where('college_id',$user->college_id)->first();
            if($user){
                return json_encode(['status'=>200, 'msg'=>$user,'college'=>$college]);
            }
            return json_encode(['status'=>500, 'msg'=>$user]);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    // 组队---获取学院数据
    public function team_getcollege(Request $request){
        $result = DB::table('team_ge')->get();
        return json_encode(['status'=>200, 'msg'=>$result]);
    }
    
    // 通过比赛名字模糊查询比赛
    public function team_search(Request $request){
        $result = DB::table("team_competition")->where('com_name','like',"%$request->competition_name%")->first();
        return json_encode(['status'=>200, 'msg'=>$result]);
    }
    
    // 组队--发布
    public function team_push(Request $request){
        $token = $request->token;  
        if(Cache::has($token)){
            $user=Cache::get($token);
            $title = $request->title;  //标题
            $post_time = $request->post_time;  //发布时间
            $com_id = $request->com_id;   //赛事id
            $num_people = $request->num_people;  //需要人数
            $aim_college = $request->aim_college;  //意向学院id
            $detail = $request->detail;  //需求详情
            $stage = $request->stage;  //进展
            $type = $request->type;  //进展
            // dd($request->all());
            $result =DB::table('team_news')->insert(['user_id'=>$user->id, 'title'=>$title, 'post_time'=>$post_time, 'com_id'=>$com_id, 'num_people'=>$num_people, 'aim_college'=>$aim_college, 'detail'=>$detail, 'stage'=>$stage]);
            
            if($result){
                return json_encode(['status'=>200, 'msg'=>'发布成功']);
            }
            return json_encode(['status'=>500, 'msg'=>'发布失败']);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    // 组队---获取竞赛详情
    public function team_competition_detail(Request $request){
        $token = $request->token;  
        if(Cache::has($token)){
            $user=Cache::get($token);
            
            $result = DB::table("team_competition")->where('com_id',$request->id)->first();
            if($result){
                return json_encode(['status'=>200, 'msg'=>$result]);
            }
            return json_encode(['status'=>500, 'msg'=>'无数据']);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    // 组队---获取帖子详情
    public function team_detail(Request $request){
        $token = $request->token;  
        if(Cache::has($token)){
            $user=Cache::get($token);
            
            $result = DB::table("team_news")->where('news_id',$request->news_id)->first();
            if($result){
                return json_encode(['status'=>200, 'msg'=>$result]);
            }
            return json_encode(['status'=>500, 'msg'=>'无数据']);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    // 组队---删除帖子
    public function team_delete(Request $request){
        $token = $request->token;  
        if(Cache::has($token)){
            $user=Cache::get($token);
            
            $result = DB::table("team_news")->where('user_id',$user->id)->where('news_id',$request->news_id)->delete();
            if($result){
                return json_encode(['status'=>200, 'msg'=>'删除成功']);
            }
            return json_encode(['status'=>500, 'msg'=>'无权删除']);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    // 组队---帖子点赞
    public function team_like(Request $request){
        $token = $request->token;  
        if(Cache::has($token)){
            $user=Cache::get($token);
            
            $result = DB::table("team_news")->where('news_id',$request->news_id)->increment('likes');
            if($result){
                return json_encode(['status'=>200, 'msg'=>'点赞成功']);
            }
            return json_encode(['status'=>500, 'msg'=>'点赞繁忙，请稍后']);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    //组队---查看发布者信息
    public function team_pusher_detail(Request $request){
        $token = $request->token;  
        if(Cache::has($token)){
            $user=Cache::get($token);
            $result = DB::table("team_user")->where('id',$request->id)->first();
            if($result){
                return json_encode(['status'=>200, 'msg'=>$result]);
            }
            return json_encode(['status'=>500, 'msg'=>'无数据']);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    //组队---修改帖子
    public function team_edit(Request $request){
        $token = $request->token;  
        if(Cache::has($token)){
            $user=Cache::get($token);
            $result = DB::table("team_news")->where('news_id',$request->news_id)->update([
                'title' => $request->title,
                'num_people' => $request->num_people,
                'aim_college' => $request->aim_college,
                'detail' => $request->detail,
                'stage' => $request->stage,
                'news_remain_time' => 10    
            ]);
            if($result){
                return json_encode(['status'=>200, 'msg'=>'修改成功']);
            }
            return json_encode(['status'=>500, 'msg'=>'修改失败']);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    // 组队---获取某用户发布的信息列表
    public function team_public_list(Request $request){
        $token = $request->token;  
        if(Cache::has($token)){
            $user=Cache::get($token);
            $result = DB::table('team_news')->where('user_id',$user->id)->get();
    
            if($result){
                return json_encode(['status'=>200, 'msg'=>$result]);
            }
            return json_encode(['status'=>500, 'msg'=>'未发布信息']);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    // 获取用户所属学院所有比赛
    public function team_allcompetition(Request $request){
       $token = $request->token;  
        if(Cache::has($token)){
            $user=Cache::get($token);
            $college = DB::table('team_ge')->where('college_name',$request->college)->first();
            
            $collegelist=DB::table('team_college')->where('college_id',$college->college_id)->get();
            
            $result=[];
            foreach($collegelist as $k=>$v){
                $result[$k]=DB::table('team_news')->where('com_id',$v->com_id)->first();
            }
            
            if($result){
                return json_encode(['status'=>200, 'msg'=>$result]);
            }
            return json_encode(['status'=>500, 'msg'=>'未发布信息']);
        }
        return json_encode(['status'=>500, 'msg'=>'请登录']);
    }
    
    