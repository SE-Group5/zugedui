/*
Navicat MySQL Data Transfer

Source Server         : blog
Source Server Version : 50557
Source Host           : 47.107.88.132:3306
Source Database       : kuaidi

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2020-12-15 00:21:35
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for team_user
-- ----------------------------
DROP TABLE IF EXISTS `team_user`;
CREATE TABLE `team_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(10) NOT NULL,
  `avatar` varchar(500) DEFAULT NULL,
  `sex` char(1) NOT NULL,
  `college_id` int(11) NOT NULL,
  `grade` varchar(3) NOT NULL,
  `experience` varchar(50) DEFAULT NULL,
  `qq` varchar(13) DEFAULT NULL,
  `weixin` varchar(25) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `user_introduction` varchar(150) DEFAULT NULL,
  `remain_time` int(11) DEFAULT '15',
  `user_status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of team_user
-- ----------------------------
INSERT INTO `team_user` VALUES ('1', '请问', '/image/user_init.jpg', '男', '1', '大一', '请问恶趣味群无', '12343536', 'qweqe123', '13012312312', 'a啊啊啊啊', '15', '1');
